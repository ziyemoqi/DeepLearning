create
    definer = root@localhost procedure execute_seckill(IN v_seckill_id varchar(32), IN v_sys_user_id varchar(32),
                                                       IN v_kill_time timestamp, OUT r_result int)
BEGIN
  DECLARE insert_count int DEFAULT 0;
    START TRANSACTION ;
    INSERT ignore INTO mall_seckill_success(mall_seckill_id,sys_user_id)VALUES(v_seckill_id,v_sys_user_id);

    SELECT ROW_COUNT() INTO insert_count;
    IF(insert_count = 0)THEN
     ROLLBACK ;
     SET r_result=-1;
    ELSEIF(insert_count<0)THEN
     ROLLBACK ;
     SET r_result=-2;

    ELSE
     UPDATE mall_seckill set stock = stock-1 WHERE mall_seckill_id = v_seckill_id and seckill_end_time > v_kill_time and seckill_start_time < v_kill_time
     AND  stock >0;
    SELECT ROW_COUNT() INTO insert_count;
     IF(insert_count<=0)THEN
      ROLLBACK ;
      SET r_result = -2;
     ELSE
      COMMIT ;
      SET r_result = 1;
     END IF;
  END IF;
END;

