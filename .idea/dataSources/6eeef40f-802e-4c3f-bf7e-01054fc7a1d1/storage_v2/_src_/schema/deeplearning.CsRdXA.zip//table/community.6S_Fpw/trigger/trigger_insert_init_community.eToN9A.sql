create definer = root@localhost trigger trigger_insert_init_community
    after INSERT
    on community
    for each row
begin

--  初始化 base_dict_type表
insert into sys_dict_type(dict_type_id,tree_code,dict_type_code,dict_type_name,can_delete,seq_num,create_user,create_time)
values (replace(UUID(),'-',''),new.tree_code,'DICT_TYPE_DEP','部门类型','0','1',new.create_user,now());

insert into sys_dict_type(dict_type_id,tree_code,dict_type_code,dict_type_name,can_delete,seq_num,create_user,create_time)
values (replace(UUID(),'-',''),new.tree_code,'CHARGE_MODE_TYPE','收款方式类型','0','6',new.create_user,now());

insert into sys_dict_type(dict_type_id,tree_code,dict_type_code,dict_type_name,can_delete,seq_num,create_user,create_time)
values (replace(UUID(),'-',''),new.tree_code,'COMPLAIN_TYPE','建议类型','0','7',new.create_user,now());

insert into sys_dict_type(dict_type_id,tree_code,dict_type_code,dict_type_name,can_delete,seq_num,create_user,create_time)
values (replace(UUID(),'-',''),new.tree_code,'REPAIR_TYPE','报修类型','0','8',new.create_user,now());

insert into sys_dict_type(dict_type_id,tree_code,dict_type_code,dict_type_name,can_delete,seq_num,create_user,create_time)
values (replace(UUID(),'-',''),new.tree_code,'REPAIR_DUTY_TYPE','报修责任类型','0','8',new.create_user,now());

insert into sys_dict_type(dict_type_id,tree_code,dict_type_code,dict_type_name,can_delete,seq_num,create_user,create_time)
values (replace(UUID(),'-',''),new.tree_code,'COMPLAIN_DUTY_TYPE','建议责任类型','0','8',new.create_user,now());

insert into sys_dict_type(dict_type_id,tree_code,dict_type_code,dict_type_name,can_delete,seq_num,create_user,create_time)
values (replace(UUID(),'-',''),new.tree_code,'QUALITY_CHECK_TYPE','品质检查类型','0','9',new.create_user,now());

insert into sys_dict_type(dict_type_id,tree_code,dict_type_code,dict_type_name,can_delete,seq_num,create_user,create_time)
values (replace(UUID(),'-',''),new.tree_code,'PARK_TYPE','车位类型','0','10',new.create_user,now());

insert into sys_dict_type(dict_type_id,tree_code,dict_type_code,dict_type_name,can_delete,seq_num,create_user,create_time)
values (replace(UUID(),'-',''),new.tree_code,'EQUIP_TYPE','设备类型','0','11',new.create_user,now());

--  初始化 sys_dict_item表
INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'DICT_TYPE_DEP', '1', '财务部', '1', '0', '', 1);

INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'DICT_TYPE_DEP', '2', '客服部', '2', '0', '',1);

INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'CHARGE_MODE_TYPE', '1', '现金', '1', '0', '系统预设参数，不可修改',0);

INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'CHARGE_MODE_TYPE', '2', '支票', '2', '0', '系统预设参数，不可修改',0);

INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'CHARGE_MODE_TYPE', '3', '刷卡', '3', '0', '系统预设参数，不可修改',0);

INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'CHARGE_MODE_TYPE', '4', '汇款', '4', '0', '系统预设参数，不可修改',0);

INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'CHARGE_MODE_TYPE', '5', '支付宝', '5', '0', '系统预设参数，不可修改',0);

INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'CHARGE_MODE_TYPE', '6', '微信', '6', '0', '系统预设参数，不可修改',0);

INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'COMPLAIN_TYPE', '1', '对环境建议', '1', '0', '',1);
INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'COMPLAIN_TYPE', '2', '对服务人员建议', '2', '0', '',1);

INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'REPAIR_TYPE', '1', '公共区域', '1', '0', '',1);
INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'REPAIR_TYPE', '2', '个人区域', '2', '0', '',1);

INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'REPAIR_DUTY_TYPE', '1', '非开发商责任', '1', '0', '',1);
INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'REPAIR_DUTY_TYPE', '2', '开发商责任', '2', '0', '',1);

INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'COMPLAIN_DUTY_TYPE', '1', '非开发商责任', '1', '0', '',1);
INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'COMPLAIN_DUTY_TYPE', '2', '开发商责任', '2', '0', '',1);

INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'QUALITY_CHECK_TYPE', '1', '设备检查', '1', '0', '',1);
INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'QUALITY_CHECK_TYPE', '2', '绿化检查', '2', '0', '',1);
INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'QUALITY_CHECK_TYPE', '3', '消防检查', '3', '0', '',1);

INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'PARK_TYPE', '1', '地上', '1', '0', '',1);
INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'PARK_TYPE', '2', '地下', '2', '0', '',1);

INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'EQUIP_TYPE', '1', '安防系统', '1', '0', '',1);
INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'EQUIP_TYPE', '2', '消防系统', '2', '0', '',1);
INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'EQUIP_TYPE', '3', '电梯系统', '3', '0', '',1);
INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'EQUIP_TYPE', '4', '给排水系统', '4', '0', '',1);
INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'EQUIP_TYPE', '5', '照明系统', '5', '0', '',1);
INSERT INTO `sys_dict_item` (`dict_item_id`, `tree_code`, `dict_type_code`, `dict_item_code`, `dict_item_name`, `seq_num`, `can_delete`, `remark`, `can_update`)
VALUES (replace(UUID(),'-',''),new.tree_code, 'EQUIP_TYPE', '6', '其他设备', '6', '0', '',1);

-- 初始化系统参数

INSERT INTO sys_parameter (parameter_id, tree_code, decimal_digits, is_print_merge, is_auto_examine, is_rate, is_collect_fee_no, is_collect_advance_no, is_collect_deposit_no, is_return_deposit_no, start_print_collect_fee_no, start_print_advance_no, start_print_collect_deposit_no, start_print_return_deposit_no, print_template_file,advance_print_template_file,deposit_print_template_file)
VALUES (replace(UUID(),'-',''),new.tree_code, '2', '1', '1', '0', '1', '1', '1', '1', '1', '1', '1', '1', 'default','default','default');


end;

